from .strategie import StratLigne,StratAnglePoly,StratPoly
from threading import Thread
class ControleurRobotReelPoly20(Thread):
    def __init__(self,robot):
        super(ControleurRobotReelPoly20,self).__init__()
        n=8
        self.robot=robot
        self.StratLigne=StratLigne(self.robot, 300/n, 500)
        self.StratPoly=StratPoly(self.robot,250,500,20) #le cas ou n est égal à 8
        self.sp=False

    def init(self):
        self.start()

    def get_distance(self) :
        return self.robot.get_distance()

    def update(self):
        if not self.StratPoly.stop():
            self.StratPoly.step()
        else:
            self.sp=True
            return self.stop

    def stop(self):
        return self.sp

