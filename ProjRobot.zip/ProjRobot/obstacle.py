class Obstacle(object):
	def __init__(self, x, y):
		self.x = x
		self.y = y

class ObstacleRectangle(object):
	def __init__(self,x, y, largeur, longueur):
		#Obstacle.__init__(self,x,y)
		self.largeur=largeur
		self.longueur=longueur

'''class ObstacleEllipse(object):
	def __init__(self,x, y, grand_r, petit_r):
		#Obstacle.__init__(self,x,y)
		self.grand_r=grand_r
		self.petit_r=petit_r

class ObstacleTriangle(object):
	def __init__(self,x, y, hauteur, base):
		#Obstacle.__init__(self,x,y)
		self.hauteur=hauteur
		self.base=base'''