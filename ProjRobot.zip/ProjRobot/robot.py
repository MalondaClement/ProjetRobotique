from math import pi,atan,cos,sin,pow,sqrt

class Robot(object):
    """La classe robot permet de construire un robot avec sa position et son angle.
        :param x,y: position x,y du robot
        :param angle: angle d'oriantation du robot en RADIAN
    """
    def __init__(self,x,y,angle):
        self.x=x
        self.y=y
        self.angle=angle
        self.largeur=20
        self.longueur=50

    def get_position(self):
        return self.x, self.y

    def obstacle (self, originex, originey, arene, pas):
        recherche_x= originex
        recherche_y= originey
        while True:
                    recherche_x+=cos(self.angle)*pas
                    recherche_y-=sin(self.angle)*pas
                    recherche_x=int(round(recherche_x,0))
                    recherche_y=int(round(recherche_y,0))
                    if recherche_x<0 or recherche_y<0 or recherche_x>arene.nb_colonne or recherche_y>arene.nb_ligne:
                        return recherche_x, recherche_y
                    if arene.matrice[recherche_y, recherche_x]==1:
                        return recherche_x, recherche_y

    def changer_angle(self, delta):
        self.angle+=delta
        while self.angle>(pi)*2:
            self.angle-=(pi)*2
        while self.angle<0:
            self.angle+=(pi)*2

    def avancer (self, distance):
        self.x+=cos(self.angle)*distance
        self.x=int(round(self.x,1))
        self.y-=sin(self.angle)*distance
        self.y=int(round(self.y,1))

    def calcul_angle(self):
        a=atan(self.largeur/self.longueur)
        return a

    def calcul_hypo(self):
        a=pow(self.largeur/2,2)+pow(self.longueur/2,2)
        return sqrt(a)


    def distancemax(self,arene):
        MAX=50
        angle=self.calcul_angle()
        t=self.calcul_hypo()
        a,b=self.obstacle(self.x,self.y-t*sin(self.angle),arene,1)
        if sqrt(pow(a-self.x, 2) + pow(b-self.y, 2)) < MAX:
            return True
        a,b=self.obstacle(self.x+t*cos(self.angle+angle),self.y-t*sin(self.angle+angle),arene,1)
        if sqrt(pow(a-self.x, 2) + pow(b-self.y, 2)) < MAX:
            return True
        a,b=self.obstacle(self.x+t*cos(self.angle-angle),self.y-t*sin(self.angle-angle),arene,1)
        if sqrt(pow(a-self.x, 2) + pow(b-self.y, 2)) < MAX:
            return True
        return False
